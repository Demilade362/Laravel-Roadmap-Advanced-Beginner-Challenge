<?php $__env->startSection('content'); ?>
    <div class="mb-3">
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Show All Users
            <i class="bi bi-person"></i>
        </a>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success text-center rounded-0">
                        <span><?php echo e(session('msg')); ?></span>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title">Users</h5>
                    <hr>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Name</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td class="d-flex align-item-center">
                                        <form action="<?php echo e(route('users.recycle', $user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success btn-sm me-2">Restore</a>
                                        </form>
                                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oluwademilade/Desktop/crm-app/resources/views/panel/users/trash.blade.php ENDPATH**/ ?>