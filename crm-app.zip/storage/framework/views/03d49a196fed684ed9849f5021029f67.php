<?php $__env->startSection('content'); ?>
    <div class="mb-3 d-flex justify-content-between align-items-center">
        <a href="<?php echo e(route('project.create')); ?>" class="btn btn-primary">Create Project
            <i class="bi bi-plus"></i>
        </a>
        <a href="<?php echo e(route('project.trash')); ?>" class="btn btn-primary p-2">
            Recycle Bin <i class="bi bi-trash"></i>
            <?php if($projectTrashed->count() > 0): ?>
                <span class="badge bg-danger ms-1 rounded-circle"><?php echo e($projectTrashed->count()); ?></span>
            <?php endif; ?>
        </a>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success text-center rounded-0">
                        <span><?php echo e(session('msg')); ?></span>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title">Tasks</h5>
                    <hr>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>DeadLine</th>
                            <th>User</th>
                            <th>Client</th>
                            <th>Status</th>
                            <th>Task Started</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($project->title); ?></td>
                                <td><?php echo e($project->deadline); ?></td>
                                <td><?php echo e($project->user->name); ?></td>
                               <?php if(!$project->client): ?>
                                    <td>Company Not Listed</td>
                                <?php else: ?>
                                    <td><?php echo e($project->client->company); ?></td>
                               <?php endif; ?>
                                <td><?php echo e($project->status); ?></td>
                                <td><?php echo e($project->created_at); ?></td>
                                <td class="d-flex align-item-center">
                                    <a href=<?php echo e(route('project.edit', $project->id)); ?>

                                                    class="btn btn-success btn-sm me-2">Edit</a>
                                    <form action="<?php echo e(route('project.destroy', $project->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Trash</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($projects->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('task-layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oluwademilade/Desktop/crm-app/resources/views/panel/tasks/index.blade.php ENDPATH**/ ?>