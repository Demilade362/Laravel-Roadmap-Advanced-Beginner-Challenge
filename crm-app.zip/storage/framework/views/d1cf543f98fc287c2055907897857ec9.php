<?php $__env->startSection('content'); ?>
    <div class="mb-3 d-flex justify-content-between align-items-center">
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Show All Users
            <i class="bi bi-person"></i>
        </a>
        <a href="<?php echo e(route('users.trash')); ?>" class="btn btn-primary">
            Recycle Bin
            <?php if($usersTrashed->count() > 0): ?>
                <span class="badge bg-danger ms-2"><?php echo e($usersTrashed->count()); ?></span>
            <?php endif; ?>
        </a>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Create User</h5>
                    <hr>
                    <div class="card-body">
                        <div class="container-width">
                            <form action="<?php echo e(route('users.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="name" class="form-control mb-3" placeholder="Your Name"
                                    value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <input type="email" name="email" class="form-control mb-3" placeholder="Your Email"
                                    value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <input type="password" name="password" class="form-control mb-3" placeholder="Your Password"
                                    value="<?php echo e(old('password')); ?>">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="password" name="password_confirmation" class="form-control mb-3"
                                    placeholder="Confirm Password" value=<?php echo e(old('password_confirmation')); ?>>

                                <button class="btn btn-success col-12">Create User</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user-layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oluwademilade/Desktop/crm-app/resources/views/panel/users/create.blade.php ENDPATH**/ ?>