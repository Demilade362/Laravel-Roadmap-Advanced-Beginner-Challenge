<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="mb-4 d-flex justify-content-between align-items-center">
            <h5 class="display-6">
                Notifications
            </h5>
            <div>
                <form action="<?php echo e(route('notification.read', auth()->id())); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-primary">Mark all As Read</button>
                </form>
            </div>
        </div>
            <div class="col-12">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-light shadow-sm d-flex justify-content-between align-items-center">
                        <div>
                            <span><?php echo e($notification->data['name']); ?> [<?php echo e($notification->data['email']); ?>] as just registered for a new account.</span>
                            <br>
                        </div>
                        <div>
                            <span><?php echo e($notification->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('notifications-layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oluwademilade/Desktop/crm-app/resources/views/panel/notifications/index.blade.php ENDPATH**/ ?>