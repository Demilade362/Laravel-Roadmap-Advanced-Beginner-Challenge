<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success text-center rounded-0">
                        <span><?php echo e(session('msg')); ?></span>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="card-title">
                        <h5>Create Project</h5>
                        <hr>
                    </div>
                    <form action="<?php echo e(route('clients.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="company" class="form-label mb-2">Company</label>
                        <input type="text" name="company" class="form-control mb-3" value="<?php echo e(old('company')); ?>">
                        <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="vat" class="form-label mb-2">Vat</label>
                        <input type="number" name="vat" class="form-control mb-3" value="<?php echo e(old('vat')); ?>">
                        <?php $__errorArgs = ['vat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="address" class="form-label mb-2">Address</label>
                        <input type="text" name="address" class="form-control mb-3" value="<?php echo e(old('address')); ?>">
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('client-layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oluwademilade/Desktop/crm-app/resources/views/panel/client/create.blade.php ENDPATH**/ ?>