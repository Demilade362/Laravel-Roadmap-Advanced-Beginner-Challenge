<?php $__env->startSection('content'); ?>
        <div class="mb-3 d-flex justify-content-between align-items-center">
            <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary">Create Client
                <i class="bi bi-plus"></i>
            </a>
            <a href="<?php echo e(route('clients.trash')); ?>" class="btn btn-primary p-2">
                Recycle Bin <i class="bi bi-trash"></i>
                <?php if($clientTrashed->count() > 0): ?>
                    <span class="badge bg-danger ms-1 rounded-circle"><?php echo e($clientTrashed->count()); ?></span>
                <?php endif; ?>
            </a>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm">
                    <?php if(session('msg')): ?>
                        <div class="alert alert-success text-center rounded-0">
                            <span><?php echo e(session('msg')); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title">Clients List</h5>
                        <hr>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Company</th>
                                <th>VAT</th>
                                <th>Address</th>
                                <th>Became Client on</th>
                                <th>Client User</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($client->company); ?></td>
                                    <td><?php echo e($client->vat); ?></td>
                                    <td><?php echo e($client->address); ?></td>
                                    <td><?php echo e($client->created_at); ?></td>
                                    <td><?php echo e($client->clientable->name); ?></td>
                                    <td class="d-flex align-item-center"><a href=<?php echo e(route('clients.edit', $client->id)); ?>

                                            class="btn btn-success btn-sm me-2">Edit</a>
                                        <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($clients->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('client-layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oluwademilade/Desktop/crm-app/resources/views/panel/client/index.blade.php ENDPATH**/ ?>